user_pref("extensions.enabledAddons", "mr-IN%40dictionaries.addons.mozilla.org:9.3");
